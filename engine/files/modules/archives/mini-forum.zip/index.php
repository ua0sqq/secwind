<?php
    
	include_once $_SERVER['DOCUMENT_ROOT'] . '/engine/includes/start.php';

	$set['title'] = 'Форум';

	define('FORUM', dirname(__FILE__) . '/');

	Core::get(array('cache.class', 'router.class', 'query_builder.class'));

	$params = array(
		'show' => array('default' => 'forum', 'maybe_values' => 'forum,razdel,topic'),
		'id' => array('default' => 0, 'numeric' => 'intval'),
		'page' => array('default' => 1),
		'act' => array('default' => ''));

	$route = new Router;
	$builder = new Query_builder;

	$route->check($params);

	$_GET['page'] = str_replace('page=', '', $route->page);

	switch($route->show)
	{
		default:
		case 'forum':
			include 'includes/razdel.create.php';
		break;

		case 'razdel':
			include 'includes/razdel.check.php';
		break;

		case 'topic':
			include 'includes/topic.check.php';
		break;
	}

	include 'includes/'.$route->show.'.view.php';
	require incDir . 'foot.php';