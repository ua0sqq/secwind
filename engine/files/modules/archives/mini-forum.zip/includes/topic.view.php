<?php
	
	// Подключаем нужные классы

	Core::get(array('text.class', 'page.class'));
	
	Include FORUM . 'includes/topic.act.php';

	// Количество постов в теме

	$total = $sql->query('SELECT COUNT(*) FROM `mf_posts` where `topic_id` = '.$route->id)->result();

	// Для пагинации
	$page = new page($total, $set['p_str']);

	//Можно ли отправлять сообщения
	$can_send = $user_id && $topic['closed'] == 'no' || ($topic['closed'] == 'yes' && $moder);
	
	// Получаем посты

	$sql->query('
		select `mf_posts`.`id` as `post_id`,
			`mf_posts`.`time`,
			`mf_posts`.`text`,
			`user`.`id`, 
			`user`.`nick`,
			`user`.`pol` 
		FROM `mf_posts`
		LEFT JOIN `user` 
			ON `mf_posts`.`user_id`=`user`.`id`
		WHERE `mf_posts`.`topic_id` = '.$route->id.'
		ORDER BY `mf_posts`.`id` 
		ASC LIMIT '. $page->limit());

	?>
		<a href="?show:razdel/id:<?php echo $topic['id_razdel']?>"><div class="link"><img src="icons/left.png"/> <?php echo $razdel['name']?></div></a>
		<a href=".?"><div class="link"> <img src="icons/left.png"/> Форум</div></a>
	<?php

	// Фиксация ТС

	echo 
	'<div class="link">'.
		Core::user_show(Core::get_user($topic['author_id']), array('status' => $topic['time'], 'is_time' => 1, 'post' => 
		'<span class="status">'.$topic['name'].'</span>'.($topic['closed'] == 'yes' ? ' <b style="color:red;float:right">[Тема закрыта]</b>' : ''). '<br />'.
		($route->page == 1 ? text::output($topic['descr']) : mb_substr($topic['descr'], 0, 50)))).
	'</div>';

	if ($moder)
	{
		?>
			<form action="?show:topic/id:<?=$route->id?>/act:delete_posts" method="post">
			<input type="submit" name="act" value="Удалить посты"/>&nbsp;&nbsp;&nbsp;
			<input type="submit" name="act" value="<?=($topic['closed'] == 'no' ? 'Закрыть' : 'Открыть')?>"/>&nbsp;&nbsp;&nbsp;
			<input type="submit" name="act" value="Изменить"/>&nbsp;&nbsp;&nbsp;
			<input type="submit" name="act" value="Удалить тему"/>
		<?php
	}

	if ($total)
	{
		// Пагинация

		$page->display('?show:topic/id:'.$topic['id'].'/page:');


		// Вывод постов

	    while($posts = $sql->fetch())
		{
		    echo
				'<div class="link">'.($moder ? '<input type="checkbox" name="delete_posts[]" value="'.$posts['post_id'].'"/> ' : '').
				'<a name="'.$posts['post_id'].'"></a>'.
				Core::user_show($posts, 
					array('status' => $posts['time'], 
						'is_time' => true, 
						'post' => text::output($posts['text']) . ($can_send ? '<a style="float:right" href="?show:topic/id:'.$topic['id'].'/post_id:'.$posts['post_id'].'/act:reply">[  отв  ]</a>' : ''))).
				'</div>';
		}
		

		// Пагинация

		$page->display('?show:topic/id:'.$topic['id'].'/page:');

		unset($config, $posts);
	}


	if ($moder)
	{
		echo '</form>';
	}
	

	// Форма добавления поста

	if ($can_send)
	{
		include 'forms/post.add.html';
	}

	?>
		<a href="?show:razdel/id:<?php echo $topic['id_razdel']?>"><div class="link"><img src="icons/left.png"/> <?php echo $razdel['name']?></div></a>
		<a href=".?"><div class="link"> <img src="icons/left.png"/> Форум</div></a>
	<?php
	unset($topic, $razdel, $total, $page);
	$sql->free();