<?php

	if ($route->act == 'edit')
	{
		include 'includes/razdel.edit.php';
	}
	elseif ($route->act == 'add_topic')
	{
		include 'includes/topic.add.php';
	}

	$set['title'] = 'Форум / ' . $forum['name'];
	
	require incDir . 'head.php';

	Core::get(array('cache.class', 'page.class'));
	$cache = new cache(tmpDir . 'mf_razdel[id='.$route->id.';page='.$route->page.'].swc');
	$total  = $sql->query('select count(*) from `mf_topics` where `id_razdel` = '. $route->id)->result();
	$page = new page($total, $set['p_str']);
	$page->display('?show:razdel/id:'.$route->id.'/');

	if (!$cache->life() || isset($upd_cache))
	{
		ob_start();
		$builder->
			select('id', 'name', 'closed')->
			from('mf_topics')->where('id_razdel', '=', $route->id)->
			order('id', 'DESC')->
			limit($page->limit());
		$sql->query($builder->query);
		while($topic = $sql->fetch())
		{
			echo '<a href="?show:topic/id:'.$topic['id'].'/'.$topic['name'].'" class="link"><img src="icons/topic'.($topic['closed'] == 'yes' ? '_closed' : null).'.png"/>'.$topic['name'].'</a>';
		}
		unset($topic);
		$cache->write();
		$builder->reset();
	}

	echo $cache->read();

	$page->display('?show:razdel/id:'.$route->id.'/');

	echo 
		($user_id ? '<a href="?show:razdel/id:'.$route->id.'/act:add_topic"><div class="menu_razd"> <img src="icons/add.png"/> Новая тема</div></a>' : '').
		($moder ? '<a href="?show:razdel/id:'.$route->id.'/act:edit"><div class="menu_razd"> <img src="icons/razdel.png"/> Редактировать раздел</div></a>' : '').
		'<a href="."><div class="menu_razd"> <img src="icons/razdel.png"/> Форум</div></a>';