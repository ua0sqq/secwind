<?php
	if ($user_id)
	{
		if (isset($_POST['name'], $_POST['descr']))
		{
			$builder->
				insert('mf_topics')->
				set(array(
				'id_razdel' => $route->id,
				'name' => Core::form('name'),
				'descr' => Core::form('descr'),
				'author_id' => $user_id,
				'time' => time(),
				'closed' => ($moder && Core::form('close') ? 'yes' : 'no')));
			$sql->query($builder->query);
			$builder->reset();
			header('Location: ?show:topic/id:'.mysqli_insert_id($sql->db));
			$upd_cache = true;
		}
		else
		{
			include incDir . 'head.php';
			include FORUM . 'forms/topic.add.html';
			include incDir . 'foot.php';
		}
	}