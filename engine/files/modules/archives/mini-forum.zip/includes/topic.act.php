<?php
	switch(isset($_POST['act']) ? $_POST['act'] : $route->act)
	{
		case 'add_post':

			// Добавление сообщения

			if ($user_id && !empty($_POST['text']))
			{
				$builder->insert('mf_posts')->set(array('topic_id' => $route->id, 'user_id' => $user_id, 'time' => $time, 'text' => Core::form('text')));
				$sql->query($builder->query);
				$post_id = mysqli_insert_id($sql->db);
				Core::stop('?show:topic/id:'.$topic['id'].'/page:end#'.$post_id);
				$builder->reset();
			}
		break;

		case 'Удалить посты':

			// Удаление постов

			if ($moder && !empty($_POST['delete_posts']))
			{
				$builder->delete('mf_posts')->where('id', 'in', my_esc(implode(',', $_POST['delete_posts'])));
				$sql->query($builder->query);
				Core::msg_show('Удалено постов: '.count($_POST['delete_posts']), 'menu_razd');
				$builder->reset();
			}
		break;

		case 'Закрыть':
		case 'Открыть':

			// Открываем, закрываем тему

			if ($moder)
			{
				$topic['closed'] = $topic['closed'] == 'yes' ? 'no' : 'yes';
				$builder->update('mf_topics')->set(array('closed' => $topic['closed']));
				$builder->where('id', '=', $route->id);
				$sql->query($builder->query);
				$builder->reset();
			}
		break;

		case 'Изменить':
			// Редактирование темы
		
			if ($moder)
			{
				if (isset($_POST['name'], $_POST['descr']))
				{
					$topic['name'] = Core::form('name');
					$topic['descr'] = Core::form('descr');
					$topic['closed'] = Core::form('close') ? 'yes' : 'no';

					$builder->
						update('mf_topics')->
						set(array(
							'name' => $topic['name'],
							'descr' => $topic['descr'],
							'closed' => $topic['closed']));
					$builder->where('id', '=', $route->id);
					$sql->query($builder->query);
					$builder->reset();
				}
				else
				{
					include 'forms/topic.edit.html';
					include incDir . 'foot.php';
				}
			}
		break;

		case 'Удалить тему':
		case 'delete_topic':
			if ($moder)
			{
				if ($route->delete)
				{
					$sql->multi('DELETE FROM `mf_topics` WHERE `id` = '.$route->id.';DELETE FROM `mf_posts` WHERE `topic_id` = '.$route->id);
					Cache::multi_delete('mf_razdel[id='.$topic['id_razde'], tmpDir);
					$builder->reset();
					Core::stop('?show:razdel/id:'.$topic['id_razdel']);
				}
				else
				{
					?>
					Вы действительно хотите удалить тему?
					<a href="?show:topic/id:<?=$route->id?>/act:delete_topic/delete:yes"><div class="link">Удалить</div></a>
					<a href="?show:topic/id:<?=$route->id?>"><div class="link">В тему</div></a>
					<?php
					include incDir . 'foot.php';
				}
			}
		break;
		
		case 'reply':
		
		if ($sql->query('SELECT COUNT(*) FROM `mf_posts` WHERE `topic_id` = '. $route->id . ' AND `id` = '.$route->post_id)->result() > 0)
		{
			$reply = $sql->query('SELECT `text`, `time`, `user_id` FROM `mf_posts` WHERE `topic_id` = '. $route->id . ' AND `id` = '.$route->post_id . ' LIMIT 1')->fetch();
			$poster = Core::get_user($reply['user_id']);
			Core::msg_show(Core::user_show($poster, array('status' => $reply['time'], 'is_time' => true, 'post' => text::output($reply['text']))), 'post');
			include 'forms/post.reply.html';
			include incDir . 'foot.php';
		}
		
		break;
	}