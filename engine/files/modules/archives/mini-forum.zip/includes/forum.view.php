<?php
	$cache = new cache(tmpDir . 'forum_index.swc');

	if (!$cache->life())
	{
		ob_start();
		$builder->select('id', 'name')->from('mf_razdel');

		if (!$moder)
		{
			$builder->where('admin', '=', 'no');
		}

		$sql->query($builder->query);

		if ($sql->num_rows() == 0)
		{
			echo '<div class="post">Нет разделов</div><a class="link" href="/">Главная</a>';
		}
		else
		{
			while($forum = $sql->fetch())
			{
				echo '<a href="?show:razdel/id:'.$forum['id'].'" class="link"><img src="icons/razdel.png"/>  '.$forum['name'].'</a>';
			}
		}
		$sql->free();
		$cache->write();
		$builder->reset();
	}

	echo $cache->read();