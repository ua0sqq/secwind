<?php
	if ($moder)
	{
		if (isset($_POST['name']))
		{
			$upd_cache = true;
			$forum['name'] = Core::form('name');
			$forum['admin'] = Core::form('admin') ? 'yes' : 'no';
			$builder->update('mf_razdel')->set(array('name' => $forum['name'], 'admin' => $forum['admin']));
			$builder->where('id', '=', $route->id);
			$sql->query($builder->query);
			$builder->reset();
		}
		else
		{
			include incDir . 'head.php';
			include 'forms/razdel.edit.html';
			include incDir . 'foot.php';
		}
	}