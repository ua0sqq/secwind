<?php
	$builder->select('name', 'admin')->from('mf_razdel')->where('id', '=', $route->id);
	$sql->query($builder->query);

	if (!$sql->num_rows())
	{
		require incDir . 'head.php';
	    Core::msg_show('Раздел не найден');
		echo '<a class="link" href=".">Форум</a><a class="link" href="/">Главная</a>';
		require incDir . 'foot.php';
	}

	$forum = $sql->fetch();

	if ($forum['admin'] == 'yes' && !$moder)
	{
		require incDir . 'head.php';
		Core::msg_show('Раздел только для админов');
		echo '<a class="link" href=".">Форум</a><a class="link" href="/">Главная</a>';
		require incDir . 'foot.php';
	}

	$builder->reset();