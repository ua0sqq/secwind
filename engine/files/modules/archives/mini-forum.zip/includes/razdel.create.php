<?php

	include incDir . 'head.php';

	if ($admin)
    {
	    if ($route->act == 'create')
		{
			if (!empty($_POST['name']))
			{
				$builder->insert('mf_razdel')->set(array('name' => Core::form('name')));
				$sql->query($builder->query);
				if (file_exists(tmpDir . 'forum_index.swc'))
				unlink(tmpDir . 'forum_index.swc');
				$builder->reset();
			}
			else
			{
				include 'forms/razdel.create.html';
				include incDir . 'foot.php';
			}
		}
		else
			echo '<div class="link"><img src="icons/add.png"/> <a href="?act:create">Новый раздел</a></div>';
	}