<?php
	$topic = $sql->query('select * from `mf_topics` where `id` = '. $route->id)->fetch();
	
	$razdel = $sql->query('select `name`, `admin` from `mf_razdel` where `id` = '. $topic['id_razdel'])->fetch();
	
	if (!$topic || ($razdel['admin'] == 'yes' && !$moder))
	{
	    Core::stop('?show:razdel/id:'.$topic['id_razdel']);
	}

	$meta_og['title'] = $set['title'] = 'Форум / ' . $topic['name'];
	$meta_og['description'] = $set['meta_description'] = $topic['descr'];
	$set['meta_keywords']   = $topic['name'];

	require incDir . 'head.php';