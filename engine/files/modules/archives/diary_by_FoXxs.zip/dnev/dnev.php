<?php
	include '../engine/includes/start.php';

	if (!isset($_GET['id']))
		Core::stop('/index.php');


	if ($sql->query("SELECT COUNT(*) FROM `dnev` WHERE `id` = '$id'")->result() == 0)
		Core::stop('/index.php?');

	//$dnev=mysql_fetch_assoc($sql->query("SELECT * FROM `dnev` WHERE `id` = '".intval($_GET['id'])."'"));
	$dnevQ = $sql->query("SELECT * FROM `dnev` WHERE `id` = '$id'");
	$dnev = $sql->fetch();

	$dnev_avtQ = $sql->query("SELECT * FROM `user` WHERE `id` = '" . $dnev['id_user'] . "'");
	$dnev_avt = $sql->fetch();

	$k_kom = $sql->query("SELECT COUNT(*) FROM `dnev_kom` WHERE `id_dnev` = '" . $dnev['id'] . "'")->result();
	$sql->query("UPDATE `dnev` SET `komm` = '$k_kom' WHERE `id`= '" . $dnev['id'] . "'");

	$all_see = $sql->query("SELECT COUNT(*) FROM `dnev_look` WHERE `id_dnev` = '" . $dnev['id'] . "'")->result();
	$sql->query("UPDATE `dnev` SET `look` = '$all_see' WHERE `id`= '" . $dnev['id'] . "'");

	if ($dnev['read'] == 2 && (!$admin || $dnev_avt['id'] != $user['id']))
	{
		Core::stop('/index.php');
	}

	
	if (isset($_GET['foto_add']) && ($user['id']==$dnev_avt['id'] || $admin))
	{
		$set['title'] = htmlspecialchars($dnev['name']).' Фото';

		include H.'engine/includes/head.php';


		if (isset($_GET['ok']) && $dnev_avt['id']==$user['id']) {

		if (isset($_FILES['file1']))
		{
			if (preg_match('#\.jpe?g$#i',$_FILES['file1']['name']) && $imgc=@imagecreatefromjpeg($_FILES['file1']['tmp_name']))
			{
			if (imagesx($imgc)>128 || imagesy($imgc)>128)
			{
$img_x=imagesx($imgc);
$img_y=imagesy($imgc);
if ($img_x==$img_y)
{
$dstW=128; // ширина
$dstH=128; // высота 
}
elseif ($img_x>$img_y)
{
$prop=$img_x/$img_y;
$dstW=128;
$dstH=ceil($dstW/$prop);
}
else
{
$prop=$img_y/$img_x;
$dstH=128;
$dstW=ceil($dstH/$prop);
}

$screen=imagecreatetruecolor($dstW, $dstH);
imagecopyresampled($screen, $imgc, 0, 0, 0, 0, $dstW, $dstH, $img_x, $img_y);
imagedestroy($imgc);

imagejpeg($screen,H."dnev/images/$dnev[id]_$user[id]_1.jpg",100);
@chmod(H."dnev/images/$dnev[id]_$user[id]_1.jpg",0777);
imagedestroy($screen);
}
else
{
copy($_FILES['file1']['tmp_name'], H."dnev/images/$dnev[id]_$user[id]_1.jpg");
}
}
}

if (isset($_FILES['file2']))
{
if (preg_match('#\.jpe?g$#i',$_FILES['file2']['name']) && $imgc=@imagecreatefromjpeg($_FILES['file2']['tmp_name']))
{
if (imagesx($imgc)>128 || imagesy($imgc)>128)
{
$img_x=imagesx($imgc);
$img_y=imagesy($imgc);
if ($img_x==$img_y)
{
$dstW=128; // ширина
$dstH=128; // высота 
}
elseif ($img_x>$img_y)
{
$prop=$img_x/$img_y;
$dstW=128;
$dstH=ceil($dstW/$prop);
}
else
{
$prop=$img_y/$img_x;
$dstH=128;
$dstW=ceil($dstH/$prop);
}

$screen=imagecreatetruecolor($dstW, $dstH);
imagecopyresampled($screen, $imgc, 0, 0, 0, 0, $dstW, $dstH, $img_x, $img_y);
imagedestroy($imgc);

imagejpeg($screen,H."dnev/images/$dnev[id]_$user[id]_2.jpg",100);
@chmod(H."dnev/images/$dnev[id]_$user[id]_2.jpg",0777);
imagedestroy($screen);
}
else
{
copy($_FILES['file2']['tmp_name'], H."dnev/images/$dnev[id]_$user[id]_2.jpg");
}
}
}

if (isset($_FILES['file3']))
{
if (preg_match('#\.jpe?g$#i',$_FILES['file3']['name']) && $imgc=@imagecreatefromjpeg($_FILES['file3']['tmp_name']))
{
if (imagesx($imgc)>128 || imagesy($imgc)>128)
{
$img_x=imagesx($imgc);
$img_y=imagesy($imgc);
if ($img_x==$img_y)
{
$dstW=128; // ширина
$dstH=128; // высота 
}
elseif ($img_x>$img_y)
{
$prop=$img_x/$img_y;
$dstW=128;
$dstH=ceil($dstW/$prop);
}
else
{
$prop=$img_y/$img_x;
$dstH=128;
$dstW=ceil($dstH/$prop);
}

$screen=imagecreatetruecolor($dstW, $dstH);
imagecopyresampled($screen, $imgc, 0, 0, 0, 0, $dstW, $dstH, $img_x, $img_y);
imagedestroy($imgc);

imagejpeg($screen,H."dnev/images/$dnev[id]_$user[id]_3.jpg",100);
@chmod(H."dnev/images/$dnev[id]_$user[id]_3.jpg",0777);
imagedestroy($screen);
}
else
{
copy($_FILES['file3']['tmp_name'], H."dnev/images/$dnev[id]_$user[id]_3.jpg");
}
}
}

}

if (isset($_GET['del'])) {
unlink(H.'dnev/images/'.$_GET['del'].'.jpg');
	}
echo "Внимание!Можно загружать картинки только формата <font color='red'>JPG</font><br />\n";

echo "<form method='post' enctype='multipart/form-data' action='?id=$dnev[id]&amp;foto_add&amp;ok'>\n";

if (is_file(H.'dnev/images/'.$dnev['id'].'_'.$user['id'].'_1.jpg')) {
echo "<img src='images/$dnev[id]_$user[id]_1.jpg'/><br/>\n";
echo "[<a href='?id=$dnev[id]&amp;foto_add&amp;del=$dnev[id]_$user[id]_1'>Удалить</a>]<br/>\n";
	}

echo "<input type='file' name='file1' accept='image/jpeg' /><br/>\n";

if (is_file(H.'dnev/images/'.$dnev['id'].'_'.$user['id'].'_2.jpg')) {
echo "<img src='images/$dnev[id]_$user[id]_2.jpg'/><br/>\n";
echo "[<a href='?id=$dnev[id]&amp;foto_add&amp;del=$dnev[id]_$user[id]_2'>Удалить</a>]<br/>\n";
	}

echo "<input type='file' name='file2' accept='image/jpeg' /><br/>\n";

if (is_file(H.'dnev/images/'.$dnev['id'].'_'.$user['id'].'_3.jpg')) {
echo "<img src='images/$dnev[id]_$user[id]_3.jpg'/><br/>\n";
echo "[<a href='?id=$dnev[id]&amp;foto_add&amp;del=$dnev[id]_$user[id]_3'>Удалить</a>]<br/>\n";
	}


echo "<input type='file' name='file3' accept='image/jpeg' /><br/>\n";

echo "<input value='Загрузить изображения' type='submit' /><br />\n";
echo "</form>\n";

echo "<div class='post'>";
echo "<a href='?id=$dnev[id]'>".htmlspecialchars($dnev['name'])."</a>";
echo "</div>";

include incDir . 'foot.php';
	}

if (isset($_GET['edit']) && ($user['id']==$dnev_avt['id'] || $admin)) {


if (isset($_GET['ok'])) {

$name=Core::form('name');

if (mb_strlen($name)<3)$err='Короткое название для темы';
if (mb_strlen($name)>32)$err='Название темы не должно быть длиннее 32-х символов';

$msg=Core::form('msg');
if (mb_strlen($msg)<15)$err='Короткое сообщение';
if (mb_strlen($msg)>100000)$err='Длина сообщения превышает предел в 5000 символа';


if (!isset($err)) {
$sql->query("UPDATE `dnev` SET `name` = '$name', `msg` = '$msg', `read` = '".intval($_POST['read'])."', `write` = '".intval($_POST['write'])."' WHERE `id`= '$dnev[id]'");

header("Location: dnev.php?id=$dnev[id]");
exit;
	}
	}

$set['title']=$dnev['name']."| редактирование";

include incDir . 'head.php';


echo "<form method='post' action='?id=$dnev[id]&amp;edit&amp;ok'>";
echo "Название (3-32 символа):<br />\n";
echo "<input name='name' type='text' maxlength='32' value='$dnev[name]' /><br />\n";
echo "Сообщение (15-5000 символов):<br />\n";
echo "<textarea name='msg'>$dnev[msg]</textarea><br />\n";

echo "Читатели:<br />\n<select name='read'>\n";
echo "<option value='0'".($dnev['read']==0?" selected='selected'":null).">Все</option>\n";
echo "<option value='2'".($dnev['read']==2?" selected='selected'":null).">Только я</option>\n";
echo "</select><br />\n";

echo "Писатели:<br />\n<select name='write'>\n";
echo "<option value='0'".($dnev['write']==0?" selected='selected'":null).">Все</option>\n";
echo "<option value='2'".($dnev['write']==2?" selected='selected'":null).">Только я</option>\n";
echo "</select><br />\n";

echo "<input value='Изменить' type='submit' /><br />\n";
echo "</form>\n";

echo "<div class='foot'>";
echo "&laquo; <a href='?id=$dnev[id]'>$dnev[name]</a>";
echo "</div>";

include incDir . 'foot.php';
	}

if (isset($_GET['otv'])) {


$dnev=$sql->query("SELECT * FROM `dnev` WHERE `id` = '".$id."'")->fetch();
$dnev_avt=$sql->query("SELECT * FROM `user` WHERE `id` = '$dnev[id_user]'")->fetch();

$user_temp=$sql->query("SELECT `id`, `nick` FROM `user` WHERE `id` = '".intval($_GET['otv'])."'")->fetch();


if (isset($user) && isset($_POST['msg'])) {

$msg=Core::form('msg');
if (mb_strlen($msg)<4)$err='Короткое сообщение';
if (mb_strlen($msg)>10000)$err='Длина сообщения превышает предел в 1000 символов';

if (!isset($err)) {
$sql->query("INSERT INTO `dnev_kom` (`id_dnev`, `id_user`, `msg`, `otv`, `time`) values('$dnev[id]', '$user[id]', '$msg', '$user_temp[id]', '$time')");

header("Location: dnev.php?id=$dnev[id]");
exit;
	}
	}


$set['title']=$dnev['name']."| ответ $user_temp[nick]";

include incDir . 'head.php';


if (isset($user) && ($dnev['write']==0 || ($dnev['write']==2 && ($dnev_avt['id']==$user['id']) || $admin))) {
echo "<form method='post' name='message' action='?id=$dnev[id]&amp;otv=$user_temp[id]'>\n";

echo "Сообщение (4-1000 символов):<br />\n<textarea name=\"msg\">".(isset($_POST['msg'])?htmlspecialchars($_POST['msg']):$user_temp['nick'] . ', ')."</textarea><br />\n";

echo "<input name='post' value='Ответить' type='submit' /><br />\n";
echo "</form>\n";

echo "<div class='post'>";
echo "<img src='/style/back.gif' alt='' class='icon'/>\n";
echo "<a href='?id=$dnev[id]'>$dnev[name]</a>";
echo "</div>";

include incDir . 'foot.php';
	}
else {
header("Location: dnev.php?id=$dnev[id]");
exit;
	}

}


	if (isset($user) && isset($_POST['msg']))
	{
		$msg = my_esc($_POST['msg']);
		
		if (mb_strlen($msg, 'UTF-8') < 4){
			Core::msg_show('Короткое сообщение');
			
		} elseif (mb_strlen($msg, 'UTF-8') > 10000){
			Core::msg_show('Длина сообщения превышает предел в 1000 символов');

		} else {
			$sql->query("INSERT INTO `dnev_kom` (`id_dnev`, `id_user`, `msg`, `time`) values('" . $dnev['id'] . "', '" . $user['id'] . "', '$msg', '$time')");
		Core::stop('dnev.php?id='.$dnev['id']);
	}
	}

if (isset($_GET['del'])) {
if ($user['id']==$dnev_avt['id'] || $admin) {
$sql->query("DELETE FROM `dnev_kom` WHERE `id` = '".intval($_GET['del'])."' AND `id_dnev` = '$dnev[id]'");
header("Location: dnev.php?id=$dnev[id]");
exit;
	}
else {
header("Location: /");
exit;
	}
	}

if (isset($_GET['del_all_com'])) {
if ($user['id']==$dnev_avt['id'] || $admin) {
$sql->query("DELETE FROM `dnev_kom` WHERE `id_dnev` = '$dnev[id]'");
header("Location: dnev.php?id=$dnev[id]");
exit;
	}
else {
header("Location: /");
exit;
	}
	}

if (isset($_GET['del_full'])) {
if ($user['id']==$dnev_avt['id'] || $admin) {
$sql->query("DELETE FROM `dnev` WHERE `id` = '$dnev[id]'");
$sql->query("DELETE FROM `dnev_kom` WHERE `id_dnev` = '$dnev[id]'");
	for ($ie=1; $ie<4; ++$ie)
	{
		if (is_file(H.'dnev/images/'.$dnev['id'].'_'.$dnev_avt['id'].'_'.$ie.'.jpg'))
		{
			unlink(H.'dnev/images/'.$dnev['id'].'_'.$dnev_avt['id'].'_'.$ie.'.jpg');
		}
	}
header("Location: /dnev/");

exit;
	}
else {
header("Location: /");
exit;
	}
	}

if (isset($_GET['hide'])) {
if ($user['id']==$dnev_avt['id'] || $admin) {
$sql->query("UPDATE `dnev_kom` SET `hide` = '".intval($_GET['set'])."' WHERE `id`= '".intval($_GET['hide'])."'");
header("Location: dnev.php?id=$dnev[id]");
exit;
	}
else {
header("Location: /");
exit;
	}
	}
	
	
	
	
	


	if (isset($user) && $user['id'] != $dnev_avt['id'])
	{
		$user_see=$sql->query("SELECT COUNT(*) FROM `dnev_look` WHERE `id_dnev` = '$dnev[id]' AND `id_user` = '$user[id]'")->result();

		if ($user_see == 0)
			$sql->query("INSERT INTO `dnev_look` (`id_dnev`, `id_user`, `time`) values('" . $dnev['id'] . "', '" . $user['id'] . "', '$time')");

		if ($user_see != 0)
			$sql->query("UPDATE `dnev_look` SET `time` = '$time' WHERE `id_user`= '" . $user['id'] . "' AND `id_dnev` = '" . $dnev['id'] . "'");
	}

	
	
	
	$set['title'] = $dnev['name'];

	include H.'engine/includes/head.php';
	

	echo "<img src='icons/diary.gif' alt='' class='icon'/> ";
	echo $dnev['name'];
	echo "<br/>\n";
	echo "<img src='icons/clock.gif' alt='' class='icon'/> ".Core::time($dnev['time'])."<br/>\n";


	for ($ie=1; $ie<4; ++$ie)
	{
		if (is_file(H.'dnev/images/'.$dnev['id'].'_'.$dnev_avt['id'].'_'.$ie.'.jpg'))
		{
			echo "<img style='width:30%' src='images/$dnev[id]_$dnev_avt[id]_$ie.jpg'/> &nbsp; ";
		}
	}

	echo "<div class='post'>";
	echo $dnev['msg']."<br/>\n";
	echo "</div>";

	
	
	echo '<div class="post">
		<span class="status">Читатели: </span><span class="ank_d">';
		
	if ($dnev['read'] == 0)
		echo 'Все';

	else
		echo 'Только я';

		
		
	echo '</span><br />
		<span class="status">Писатели: </span><span class="ank_d">';
		
	if ($dnev['write'] == 0)
		echo 'Все';

	else
		echo 'Только я';
	echo '</span><br />';


	if ($user['id'] == $dnev_avt['id'])
		echo '[<a href="dnev.php?id='.$dnev['id'].'&amp;foto_add">Фото</a>]';

	if ($user['id'] == $dnev_avt['id'] || $admin)
	{
		echo '[<a href="dnev.php?id='.$dnev['id'].'&amp;edit">Изменить</a>]';

		echo '[<a href="dnev.php?id='.$dnev['id'].'&amp;del_all_com">Очистить</a>]';

		echo '[<a href="dnev.php?id='.$dnev['id'].'&amp;del_full">Удалить</a>]<br/>';
	}

	$k_kom = $sql->query("SELECT COUNT(*) FROM `dnev_kom` WHERE `id_dnev` = '" . $dnev['id'] . "'")->result();
	echo 'Комментариев: '.$k_kom.'<br />';

	$all_see = $sql->query("SELECT COUNT(*) FROM `dnev_look` WHERE `id_dnev` = '" . $dnev['id'] . "'")->result();
	echo 'Просмотров: '.$all_see;
	echo "</div>";
	
	if (isset($user) && ($dnev['write'] == 0 || ($dnev['write'] == 2 && ($dnev_avt['id'] == $user['id']) || $user['group_access'] == 15))) 
	{
		echo '<form method="post" name="message" action="?id='.$dnev['id'].'">
			<textarea name="msg">'.Core::form('msg').'</textarea><br />
			<input name="post" value="Добавить комментарий" type="submit" /><br />
			</form>';
	}


	Core::get(array('page.class', 'text.class'), 'classes');
	
	$k_post = $sql->query("SELECT COUNT(*) FROM `dnev_kom` WHERE `id_dnev` = '" . $dnev['id'] . "'")->result();

	if ($k_post == 0)
	{
		echo '<div class="p_t">
			Дневник '.$dnev['name'].' еще не обсуждали<br/>
			</div>';
	}
	else
	{
		$page = new page($k_post, $set['p_str']);

	$sql->query("SELECT `user`.`nick`, `user`.`pol`, `dnev_kom`.* FROM `dnev_kom` LEFT JOIN `user` ON `user`.`id` = `dnev_kom`.`id_user` WHERE `id_dnev` = '" . $dnev['id'] . "' ORDER BY `time` DESC limit ".$page->limit());
	
	while ($post = $sql->fetch())
	{
		$data = array('post' => text::output($post['msg']), 'status' => $post['time'], 'is_time' => true);
		echo '<div class="link">';

if ($post['hide']==0 || ($post['hide']==1 && ($user['id']==$dnev_avt['id'] || $user['id']==$post['id_user'] || $admin))) {
$data['post'] = text::output($post['msg'])."\n";
	}
else
$data['post'] = "<font color='red'>[Комментарий скрыт]</font> ";

echo Core::user_show($post, $data);
echo "<span style='float: right;'><font color='#afb0a3'>".Core::time($post['time'])."</font>\n";
if (isset($user) && ($dnev['write']==0 || ($dnev['write']==2 && ($dnev_avt['id']==$user['id']) || $admin))) {
echo "<a href='dnev.php?id=$dnev[id]&amp;otv=$post[id_user]'><img src='icons/say.gif'/></a>\n";
	}
if ($user['id']==$dnev_avt['id'] || $admin) {
if ($post['hide']==0) echo "<a href='dnev.php?id=$dnev[id]&amp;hide=$post[id]&amp;set=1'><img src='icons/close.png'/></a>\n";
elseif ($post['hide']==1) echo "<a href='dnev.php?id=$dnev[id]&amp;hide=$post[id]&amp;set=0'><img src='icons/open.png'/></a>\n";
	}

if ($user['id']==$dnev_avt['id'] || $admin) {
echo "<a href='dnev.php?id=$dnev[id]&amp;del=$post[id]'><img src='icons/delete.png'/></a></span>\n";
	}
echo '</div>';
}


	$page->display('?');
	}

	echo "<div class='post'>";
echo "<img src='icons/diary.gif' alt='' class='icon'/> <a href='/dnev/user.php?id=$dnev_avt[id]'>Все записи</a> $dnev_avt[nick]<br/>\n";
echo "</div>";
echo "<div class='post'>";
echo "<img src='icons/diary.gif' alt='' class='icon'/>\n";
echo "<a href='/dnev/'>Дневники</a>\n";
echo "</div>";

	include H.'engine/includes/foot.php';