<?php
	include '../engine/includes/start.php';
	
	$set['title'] = 'Создать запись';

	include H.'engine/includes/head.php';
	

	if (!empty($_POST['name']) && !empty($_POST['msg']))
	{
		$error_d = false;
		$name = Core::form('name');
		$msg = Core::form('msg');
		//$mat = text::antimat($name, $user);
		//$mat2 = text::antimat($msg, $user);
		$mat = false;
		$mat2 = false;
		

		if (mb_strlen($name, 'UTF-8') < 3){
			Core::msg_show('Короткое название для темы');
			$error_d = true;

		} elseif (mb_strlen($name, 'UTF-8') > 32){
			Core::msg_show('Название темы не должно быть длиннее 32-х символов');
			$error_d = true;
		
		} elseif ($mat){
			Core::msg_show('В название записи обнаружен мат');
			$error_d = true;}


	
		if (mb_strlen($msg, 'UTF-8') < 15){
			Core::msg_show('Короткое сообщение');
			$error_d = true;

		} elseif (mb_strlen($msg, 'UTF-8') > 5000){
			Core::msg_show('Длина сообщения превышает предел в 5000 символа');
			$error_d = true;
			
		} elseif ($mat){
			Core::msg_show('В сообщении записи обнаружен мат');
			$error_d = true;}



		if ($error_d == false)
		{
			if (isset($_POST['go']))
			{
				$sql->query("UPDATE `user` SET `balls` = '" . ($user['balls']+5) . "' WHERE `id` = '" . $user['id'] . "' LIMIT 1");
				
				$sql->query("INSERT INTO `dnev` (`id_user`, `name`, `msg`, `read`, `write`, `time`) values('" . $user['id'] . "', '$name', '$msg', '" . intval($_POST['read']) . "', '" . intval($_POST['write']) . "', '$time')");
				
				$dnev['id'] = mysqli_insert_id($sql->db);

				Core::stop('/dnev/dnev.php?id=' . $dnev['id']);
			}
			else
			{
				echo '<div class="post"><span class="status">Предпросмотр</span><br /><span class="status">Название:</span><br />'.$name.'<br /><br /><span class="status">Тескт:</span><br />'.$msg.'</div>';
			}
		}
	}
	

	?>
	<form method="post">
		Название (3-32 символа):<br />
		<input name="name" size="27" type="text" maxlength="32" value='<?=Core::form('name')?>'><br />
		
		Сообщение (15-5000 символов):<br />
		<textarea cols="22" rows="9" name="msg"><?=Core::form('msg')?></textarea><br />
		
		<div class="post">Читатели:<br /><select name="read">
		<option value="0" checked="checked">Все</option>
		<option value="2">Только я</option>
		</select><br />
		
		Писатели:<br />
		<select name="write">
			<option value="0" checked="checked">Все</option>
			<option value="2">Только я</option>
		</select></div>
		
		<input value="Создать" type="submit"  name="go" /><input value="Предпросмотр" type="submit" name="see" />
		</form>
	<br />&laquo;<a href="index.php">Дневники</a>
	<?php
	include H.'engine/includes/foot.php';