<?php
    include '../engine/includes/start.php';
	if (!$user_id)
	    Core::stop();
	
	$set['title']='Удаление модуля Дневники';
	
	include H.'engine/includes/head.php';

	if (!$creator)Core::stop();

	if (isset($_GET['yes']))
	{
		$sql->multi("DROP TABLE `dnev`, `dnev_kom`, `dnev_look`;DELETE FROM `modules` where `name` = 'diary';");
		Core::get('delete_dir', 'functions');
		delete_dir(H . 'dnev');
		echo 'Модуль удален';
	}
	else
		echo 'Вы действительно хотите удалить модуль "Дневники"?<br /><a href="?yes">[  Да  ]</a> | <a href=".">[  Нет  ]</a>';

	include H.'engine/includes/foot.php';