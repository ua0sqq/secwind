<?php
	include '../engine/includes/start.php';
	
	$set['title'] = 'Дневники';
	
	include H.'engine/includes/head.php';

?>
	<div class='post'>
		Сортировать:
<?
		if (!isset($_GET['time']))
			echo '<a href="?time">Время</a> | ';

		if (isset($_GET['time']))
			echo '<font color="red">Время</font> | ';

		if (!isset($_GET['komm']))
			echo '<a href="?komm">Комментарии</a> | ';

		if (isset($_GET['komm']))
			echo '<font color="red">Комментарии</font> | ';

		if (!isset($_GET['look']))
			echo '<a href="?look">Просмотры</a> ';

		if (isset($_GET['look']))
			echo '<font color="red">Просмотры</font> ';


		if (isset($user))
			echo '<br /><img src="icons/diary.gif" alt="new" class="icon" /> <a href="add.php">Создать новую запись</a>';


	echo '</div>';

	Core::get('page.class');
	
	$k_post = $sql->query("SELECT COUNT(*) FROM `dnev` WHERE `read` = '0'")->result();

	$page = new page($k_post, $set['p_str']);

	$order = '`time` DESC';

	if (isset($_GET['time']))
		$order = '`time` DESC';

	if (isset($_GET['komm']))
		$order = '`komm` DESC';

	if (isset($_GET['look']))
		$order = '`look` DESC';



	$count = $sql->query("SELECT COUNT(*) FROM `dnev` WHERE `read` = '0'")->result();

	if ($count == 0)
	{
		echo 'Нет дневников';
	}
	else
	{
		$sql->query("SELECT * FROM `dnev` WHERE `read` = '0' ORDER BY $order LIMIT ".$page->limit());
		while ($dnev = $sql->fetch())
		{
			//$count_com = $sql->query("SELECT COUNT(*) FROM `dnev_kom` WHERE `id_dnev` = '" . $dnev['id'] . "'")->result();
			echo '<div class="link">
			<img src="icons/diary.gif" alt="" class="icon" />
			<a href="dnev.php?id='.$dnev['id'].'">'.htmlspecialchars($dnev['name']).'</a>
			<font color="#afb0a3">('.Core::time($dnev['time']).')</font>
			<font color="#313431"><br />
			'.htmlspecialchars(mb_substr($dnev['msg'], 0, 45)).'
			</font></div>';
		}
		$page->display('?');
	}
	
	echo "<div class='post'>";
		$all_dnev = $sql->query("SELECT COUNT(*) FROM `dnev` WHERE `read` = '0'")->result();
		$new_d = $sql->query("SELECT COUNT(*) FROM `dnev` WHERE `time` > '".(time()-86400)."' AND `read` = '0'")->result();
		$all_dnev_k = $sql->query("SELECT COUNT(*) FROM `dnev_kom`")->result();
		$new_d_k = $sql->query("SELECT COUNT(*) FROM `dnev_kom` WHERE `time` > '".(time()-86400)."' ")->result();
		echo 'Всего дневников '.$all_dnev.' <font color="red">+'.$new_d.' Сегодня</font><br />Всего комментариев '.$all_dnev_k.' <font color="red">+'.$new_d_k.' Сегодня</font>';
	echo "</div>";

	include H.'engine/includes/foot.php';