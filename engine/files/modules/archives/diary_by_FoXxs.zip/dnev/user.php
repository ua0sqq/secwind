<?php
	include '../engine/includes/start.php';

	if ($user_id)$ank['id'] = $user_id;
	if ($id)$ank['id']=$id;
	if ($ank['id'] == 0)Core::stop();

$ank=Core::get_user($ank['id']);
$set['title']='Дневники ';
include incDir . 'head.php';

echo "<div class='post'>";
echo "<img src='icons/diary.gif' alt='' class='icon'/> \n";
echo "<u>Все записи</u> <b>$ank[nick]</b>\n";
echo "</div>\n";

Core::get('page.class');

$total = $sql->query("SELECT COUNT(*) FROM `dnev` WHERE `id_user` = '$ank[id]'")->result();
$page= new page($total, $set['p_str']);

$sql->query("SELECT * FROM `dnev` WHERE `id_user` = '$ank[id]' ORDER BY `time` DESC limit ".$page->limit());
if ($total == 0) {
echo "У $ank[nick] нет записей\n";
}

while ($dnev = $sql->fetch())
{

echo "  <div class='link'>\n";



if ($dnev['read']==0)	{
echo "<img src='icons/diary.gif' alt='' class='icon'/>\n";
echo " <a href='dnev.php?id=$dnev[id]'>".htmlspecialchars($dnev['name'])."</a> <img src='icons/clock.gif' alt='' class='icon'/> ".Core::time($dnev['time'])."<br/>\n";
	}


if ($dnev['read']==2)	{
if ($user['id']==$ank['id'] || $admin) {
echo "<img src='icons/diary.gif' alt='' class='icon'/>\n";
echo "<a href='dnev.php?id=$dnev[id]'>".htmlspecialchars($dnev['name'])."</a> <img src='icons/clock.gif' alt='' class='icon'/> ".Core::time($dnev['time'])." <br/>\n";
	}
echo "<font color='red'><b>[Личный]</b></font>";
	}

echo '</div>';
}


$page->display('?id='.$ank['id'].'&amp;'); // Вывод страниц
if ($ank['id']==$user['id']) {
echo "<div class='fmenu'>";
echo "<a href='add.php'>Создать</a>";
echo "</div>";
	}

include incDir . 'foot.php';