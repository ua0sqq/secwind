CREATE TABLE IF NOT EXISTS `dnev` (
	`id` int(11) NOT NULL AUTO_INCREMENT,
	`id_user` int(11) NOT NULL,
	`name` varchar(32) NOT NULL,
	`msg` varchar(5000) NOT NULL,
	`read` enum('0','1','2') NOT NULL,
	`write` enum('0','1','2') NOT NULL,
	`time` int(11) NOT NULL,
	`look` int(11) default 0,
	`komm` int(11) default 0,
	PRIMARY KEY (`id`)
	) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;
CREATE TABLE IF NOT EXISTS `dnev_kom` (
	`id` int(11) NOT NULL AUTO_INCREMENT,
	`id_dnev` int(11) NOT NULL,
	`id_user` int(11) NOT NULL,
	`msg` varchar(1000) NOT NULL,
	`otv` int(11) NOT NULL,
	`time` int(11) NOT NULL,
	`hide` enum('0','1') DEFAULT '0',
	PRIMARY KEY (`id`)
	) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;
CREATE TABLE IF NOT EXISTS `dnev_look` (
	`id` int(11) NOT NULL AUTO_INCREMENT,
	`id_dnev` int(11) NOT NULL,
	`id_user` int(11) NOT NULL,
	`time` int(11) NOT NULL,
	PRIMARY KEY (`id`)
	) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;