<?php
/*
Mod by MyZik
*/
include '../../engine/includes/start.php';


$set['title']='Обман зрения'; // заголовок страницы
include incDir . 'head.php';

switch($act)
{
	case 'text':
	?>
<div class='link'><b>Читаем этот текст быстро:</b><br />По рзелульаттам илссеоваднийодонго англигйскго унвиертсиета, не иеемт занчнеия, в кокам пряокде рсапожолены бкувы в солве. Галвоне, чотбы преавя и пслоендяя бквуы блыи на мсете. Осатьлыне бкувы мгоут селдовтаь в плоонм бсепордяке, все рвано ткест чтаитсея  без порбелм. Пичрионй эгото ялвятеся то, что мы не чиатем кдаужю бкву по отдльенотси, а все солво цликеом.</div>
	<?php
	break;

	case 'perevert':
	?>
<div class='post'><b>Переверни мобилу на 180 градусов будет другой рисунок:</b><br />
<img src='1.jpg'/><br />
&raquo; <a href='1.jpg'>Скачать картинку</a></div>
	<?php
	break;

	case 'dvig':
	?>
<div class='post'><b>Вечный двигатель:</b><br />
<img src='2.jpg'/><br />
&raquo; <a href='2.jpg'>Скачать картинку</a></div>
	<?php
	break;
	
	case 'batman':
	?>
<div class='post'><b>Смотрите 30-40 секунд на картинку, затем опрокиньте вверх голову и моргайте, или просто попробуйте перевести взгляд на лист бумаги.</b><br />
<img src='3.jpg'/><br />
&raquo; <a href='3.jpg'>Скачать картинку</a></div>
	<?php
	break;

	case 'volsheb':
	?>
<div class='post'><b>Смотрите 30-40 секунд на картинку, затем опрокиньте вверх голову и моргайте. Из-за высокого контраста изображения и памяти сетчатки вы должны увидеть позитивное изображение</b><br />
<img src='4.jpg'/><br />
&raquo; <a href='4.jpg'>Скачать картинку</a></div>
	<?php
	break;

	case 'ischez':
	echo '<div class="post"><b>Смотрим 20-30 секунд на красную точку. Линиии должны исчезнуть</b><br /><img src="5.jpg"/><br />
&raquo; <a href="5.jpg">Скачать картинку</a></div>';
}

?>
<div class='link'>&raquo; <a href='index.php?act=text'>Прочти текст</a></div>
<div class='link'>&raquo; <a href='index.php?act=perevert'>Перевертыши</a></div>
<div class='link'>&raquo; <a href='index.php?act=dvig'>Иллюзия движения</a></div>
<div class='link'>&raquo; <a href='index.php?act=batman'>Бэтмен/иллюзия контраста</a></div>
<div class='link'>&raquo; <a href='index.php?act=volsheb'>Волшебная картинка</a></div>
<div class='link'>&raquo; <a href='index.php?act=ischez'>Исчезновeние</a></div>
<?php

	include incDir .'foot.php';